@echo off
cd /d "%~dp0"
if exist self-test.txt del self-test.txt
start /wait "" "DividedHorizon-Slice.exe" --self-test
if errorlevel 1 (echo Diagnostic failed. & pause & exit /b 1)
if not exist self-test.txt (echo No diagnostic report was produced. & pause & exit /b 1)
type self-test.txt
pause
