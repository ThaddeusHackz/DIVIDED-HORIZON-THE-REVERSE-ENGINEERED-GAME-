@echo off
cd /d "%~dp0"
start /wait "" "DividedHorizon-Slice.exe"
if errorlevel 1 (echo Game exited with an error. See README_START_HERE.txt. & pause)
